import java.util.*;

import java.io.*;

import java.lang.*;



public class ColumnarTranspose {

public static void main(String[] args) {

Scanner scan = new Scanner(System.in);

String line = System.getProperty("line.separator"); scan.useDelimiter(line);


System.out.print("1. Encryt \n2.Decrypt : ");

int option = scan.nextInt();
 
switch (option) {

case 1:

System.out.print("Enter String:");

String text = scan.next();



System.out.print("Enter Key:");

String key = scan.next();




System.out.println("\nEncrypted String : "+encryptCT(key, text).toUpperCase()); break;

case 2:

System.out.print("Enter Encrypted String:");

text = scan.next();



System.out.print("Enter Key:");

key = scan.next();




System.out.println("Decrypted String : "+decryptCT(key, text)); break;

default:

break;

}

}
 

public static String encryptCT(String key, String text) { int[] arrange = arrangeKey(key);

int lenkey = arrange.length;

int lentext = text.length();



int row = (int) Math.ceil((double) lentext / lenkey);



char[][] grid = new char[row][lenkey];

int z = 0;

for (int x = 0; x < row; x++) {

for (int y = 0; y < lenkey; y++) {

if (lentext == z) {

//	at random alpha for trailing null grid grid[x][y] = RandomAlpha();

z--; } else {

grid[x][y] = text.charAt(z);

}

z++;

}

}

String enc = "";

for (int x = 0; x < lenkey; x++) {

for (int y = 0; y < lenkey; y++) {
 
if (x == arrange[y]) {

for (int a = 0; a < row; a++) {

enc = enc + grid[a][y];

}

}

}

}

return enc;

}




public static String decryptCT(String key, String text) { int[] arrange = arrangeKey(key);

int lenkey = arrange.length;

int lentext = text.length();



int row = (int) Math.ceil((double) lentext / lenkey);



String regex = "(?<=\\G.{" + row + "})";

String[] get = text.split(regex);



char[][] grid = new char[row][lenkey];



for (int x = 0; x < lenkey; x++) {

for (int y = 0; y < lenkey; y++) {
 
if (arrange[x] == y) {

for (int z = 0; z < row; z++) {

grid[z][y] = get[arrange[y]].charAt(z);

}

}

}

}



String dec = "";

for (int x = 0; x < row; x++) {

for (int y = 0; y < lenkey; y++) {

dec = dec + grid[x][y];

}

}



return dec;

}



public static char RandomAlpha() {

//generate random alpha for null space

Random r = new Random();

return (char)(r.nextInt(26) + 'a');

}
 
public static int[] arrangeKey(String key) {

//arrange position of grid

String[] keys = key.split("");

Arrays.sort(keys);

int[] num = new int[key.length()];

for (int x = 0; x < keys.length; x++) {

for (int y = 0; y < key.length(); y++) {

if (keys[x].equals(key.charAt(y) + "")) {

num[y] = x;

break;

}

}

}

return num;

}



}






OUTPUT

F:\sem5\ns>javac ColumnarTranspose.java

F:\sem5\ns>java ColumnarTranspose

1. Encryt

2.Decrypt : 1
 
Enter String:Ruju

Enter Key:3



Encrypted String : RUJU

